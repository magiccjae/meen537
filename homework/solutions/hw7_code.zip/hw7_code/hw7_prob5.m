run D:\Dropbox\vision-3.4\rvctools\startup_rvc.m
run D:\Dropbox\rvctools_new\startup_rvc.m
clear all;
clc;

%these are just the time, position and roll/pitch/yaw vectors for the pbvs
%solution from problem 4
load results_hw7_prob4.mat;

%making a puma robot and default camera
mdl_puma560;
camera = CentralCamera('default');

%these are the same object vertices that we defined in problem 4
P = [0.3250    0.3250    0.5250    0.5250;
   -0.2500   -0.0501   -0.2500   -0.0501;
    0.9856    0.9856    0.9856    0.9856];

%these are the same initial joint angles
q0 = [0, -pi/4, 0, 0, pi/4, 0]';

%simulating the ibvs algorithm
out = sim('sl_arm_ibvs_hw_7');

%getting all the data out and reformatting it
Ts = out.get('T_ibvs');
q_ibvs = out.get('q_ibvs');
t_ibvs = out.get('t_ibvs');

q_ibvs = reshape(q_ibvs, [length(t_ibvs), p560.n]);

pos_ibvs = [];
rpy_ibvs = [];

for i = 1:1:length(t_ibvs)
    pos_ibvs = [pos_ibvs; reshape(Ts(1:3,4,i), [1,3])];
    rpy = tr2rpy(Ts(:,:,i));
    rpy_ibvs = [rpy_ibvs; rpy];
end


%comparing roll/pitch/yaw and position response for each method
figure()
plot(t_pbvs_plot, rpy_pbvs_plot(:,1), t_ibvs, rpy_ibvs(:,1), 'r--');
legend('pbvs', 'ibvs');
xlabel('time (s)');
ylabel('roll (radians)');
title('PBVS vs IBVS for roll');

figure()
plot(t_pbvs_plot, rpy_pbvs_plot(:,2), t_ibvs, rpy_ibvs(:,2), 'r--');
legend('pbvs', 'ibvs');
xlabel('time (s)');
ylabel('pitch (radians)');
title('PBVS vs IBVS for pitch');

figure()
plot(t_pbvs_plot, rpy_pbvs_plot(:,3), t_ibvs, rpy_ibvs(:,3), 'r--');
legend('pbvs', 'ibvs');
xlabel('time (s)');
ylabel('yaw (radians)');
title('PBVS vs IBVS for yaw');

figure()
plot(t_pbvs_plot, cam_pbvs_pos_plot(:,1), t_ibvs, pos_ibvs(:,1), 'r--');
legend('pbvs', 'ibvs');
xlabel('time (s)');
ylabel('x position (m)');
title('PBVS vs IBVS for x position');

figure()
plot(t_pbvs_plot, cam_pbvs_pos_plot(:,2), t_ibvs, pos_ibvs(:,2), 'r--');
legend('pbvs', 'ibvs');
xlabel('time (s)');
ylabel('y position (m)');
title('PBVS vs IBVS for y position');

figure()
plot(t_pbvs_plot, cam_pbvs_pos_plot(:,3), t_ibvs, pos_ibvs(:,3), 'r--');
legend('pbvs', 'ibvs');
xlabel('time (s)');
ylabel('z position (m)');
title('PBVS vs IBVS for z position');

%cam_ibvs_pos = T