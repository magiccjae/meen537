clear all;
close all;
clc;

%define the robot and PD gains
mdl_puma560;
p560 = p560.nofriction();
Kp = 1000*eye(p560.n);
Kd = 10*eye(p560.n);

%make a first set of simulated joint angles that result from PD control

%randomly generate the command from within the robot joint limits
q_cmd = random('unif', p560.qlim(:,1), p560.qlim(:,2))

%simulate the control
out = sim('sl_puma_PD_control');

%plot the steady state desired position and the actual joint angles over time
figure()
q_cmd_vec = [q_cmd, q_cmd]
t_cmd = [0, 5];
q = out.get('q_sim');
t = out.get('t_sim');
plot(t, q, t_cmd, q_cmd_vec, '--');
xlabel('time (s)')
ylabel('radians')


%repeat for another set of joint angles
q_cmd = random('unif', p560.qlim(:,1), p560.qlim(:,2))
out = sim('sl_puma_PD_control');

figure()
q_cmd_vec = [q_cmd, q_cmd]
t_cmd = [0, 5];
q = out.get('q_sim');
t = out.get('t_sim');
plot(t, q, t_cmd, q_cmd_vec, '--');
xlabel('time (s)')
ylabel('radians')
