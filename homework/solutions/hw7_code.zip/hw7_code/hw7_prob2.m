run D:\Dropbox\vision-3.4\rvctools\startup_rvc.m
run D:\Dropbox\rvctools_new\startup_rvc.m

clear all;
close all;
clc;

%define the robot and PD gains
mdl_puma560;
p560 = p560.nofriction();

%randomly generate the command from within the robot joint limits
q_cmd = random('unif', p560.qlim(:,1), p560.qlim(:,2))
Ts = 0.01;

%simulate the control
out = sim('sl_ctorque');
out2 = sim('sl_fforward');

ctorque_error = out.get('q_error');
ctorque_time = out.get('time');

ff_error = q_error;
ff_t = time;

figure()
plot(ff_t, ff_error);
title('feedforward error with T_s = 0.01')
xlabel('time (s)');
ylabel('error in radians');

figure()
plot(ctorque_time, ctorque_error);
title('computed torque error with T_s = 0.01')
xlabel('time (s)');
ylabel('error in radians');

Ts = 0.001;

%simulate the control
out = sim('sl_ctorque');
out2 = sim('sl_fforward');

ctorque_error = out.get('q_error');
ctorque_time = out.get('time');

ff_error = q_error;
ff_t = time;

figure()
plot(ff_t, ff_error);
title('feedforward error with T_s = 0.001')
xlabel('time (s)');
ylabel('error in radians');

figure()
plot(ctorque_time, ctorque_error);
title('computed torque error with T_s = 0.001')
xlabel('time (s)');
ylabel('error in radians');



%simulate the control for the perturbed models
p560_model=p560.perturb(0.15);
out = sim('sl_ctorque_modified');
out2 = sim('sl_fforward_modified');

ctorque_error = out.get('q_error');
ctorque_time = out.get('time');

ff_error = q_error;
ff_t = time;

figure()
plot(ff_t, ff_error);
title('feedforward error with perturbed model')
xlabel('time (s)');
ylabel('error in radians');

figure()
plot(ctorque_time, ctorque_error);
title('computed torque error with perturbed model')
xlabel('time (s)');
ylabel('error in radians');