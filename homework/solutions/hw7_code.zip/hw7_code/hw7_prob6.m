run D:\Dropbox\vision-3.4\rvctools\startup_rvc.m
run D:\Dropbox\rvctools_new\startup_rvc.m
clear all;
close all;

%make a camera
cam = CentralCamera('default');

%instantiate robot model, initial position, and vectors for plotting
mdl_puma560;
p560 = p560.nofriction();
q = [0, -pi/4, 0, 0, pi/4, 0];
qd = zeros(1, 6);
rpy_pbvs_cntrl = [];
pos_pbvs_cntrl = [];
q_pbvs_cntrl = [];
t_pbvs_cntrl = [];

%get the end effector position and set the camera at that position
T = p560.fkine(q);
cam.T = T;

%this transform defines where the object starts relative to my initial robo
%configuration
%this moves the object -0.2 meters in the x and 1 meter in z away from my
%camera/end effector position
move_obj_position = [-0.2; 0; 1;] 
%T_points = T*[rotz(pi/2), move_obj_position;
T_points = T*[eye(3), move_obj_position;
              0, 0, 0, 1];

%this is the definition of the nominal vertices for our object in
%homogenous coordinates
P_nom = [-0.1   0.1 -0.1   0.1;
         0.1    0.1 -0.1  -0.1;
         0      0    0      0;
         1      1    1      1]

%this is transforming the nominal object model out to its actual location
P = T_points*P_nom
P = P(1:3,:);

%get the pixel coordinates of the object in the camera now
p = cam.project(P);
cam.plot(P);

%from that we can estimate where the object is relative to the camera at
%least
T_est_cam = cam.estpose(P_nom, p);

%then we can define a desired position for the camera relative to the
%object, which in this case is just 1.0 meter back in the z-direction and
%aligned with the object
T_des = T*T_est_cam*[eye(3), [0; 0; -0.5];
                     0 0 0 1];

%plot everything for the initial conditions                 
figure();
p560.plot(q);
cam.plot_camera();
plot_sphere(P, 0.05, 'r');

%this is just a starting condition for the while loop
error = 1;

time = 0;
while error > 0.001
    %find how we can take small step towards our desired camera position
    T_cmd = trnorm(trinterp(T, T_des, 0.1));
    
    %do inverse kinematics to find the new commanded joint angles. 
    %Weird interactions here between the output of this function and
    %simulated computed torque controller below are causing problems
    q_goal = p560.ikine(T_cmd, q);
    
    % I tried using trajectory generation, but it didn't immediately help
    %    [q_goals,qd_goals,] = jtraj(q, q_goal, [0:0.01:0.1]);
    qd_goal = zeros(1, p560.n); %this is a hack because I'm not generating trajectories
    
    %forward simulate using the torque controller in "computed_torque"
    [t, q_model, qd_model] = p560.fdyn(0.1, @computed_torque, ...
                        q, qd, q_goal, qd_goal)

    time = time + t(end);
    q = q_model(end,:);
    qd = qd_model(end,:);
    
    %find how the end effector and camera have moved based on our robot
    %kinematic  model
    T = p560.fkine(q);
    cam.T = T;

    %update all plots
    cam.plot(P)
    p560.plot(q)
    cam.plot_camera()
    plot_sphere(P, 0.05, 'r')

    %project the object into the camera image plane now that we've moved
    p = cam.project(P)
    
    %solve for the relative pose of the object with respect to the camera
    %agian
    T_est_cam = cam.estpose(P_nom, p);
    
    %and define a desired camera pose relative to that position for the
    %camera
    T_des = T*T_est_cam*[eye(3), [0; 0; -0.5];
        0 0 0 1];
    
    %calculate our error in terms of roll, pitch, yaw and then position too
    rpy_des = tr2rpy(T_des);
    rpy = tr2rpy(T);
    error = norm(T(1:3,4)-T_des(1:3,4))+norm(rpy_des-rpy);

    rpy_pbvs_cntrl = [rpy_pbvs_cntrl; rpy]
    pos_pbvs_cntrl = [pos_pbvs_cntrl; T(1:3,4)'];
    q_pbvs_cntrl = [q_pbvs_cntrl; q];
    t_pbvs_cntrl = [t_pbvs_cntrl; time];

end

