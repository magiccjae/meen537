%HW 7 problem 3
run D:\Dropbox\vision-3.4\rvctools\startup_rvc.m
run D:\Dropbox\rvctools_new\startup_rvc.m

close all;
clear all;
clc;

load ./hw7_prob3.mat

cam = CentralCamera('default');

T_est1 = cam.estpose(P1, p1)
T_est2 = cam.estpose(P2, p2)
T_est3 = cam.estpose(P3, p3)