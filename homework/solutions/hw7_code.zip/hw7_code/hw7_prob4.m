clear all;
close all;

%make a camera
cam = CentralCamera('default');

%instantiate robot model, initial position, and vectors for plotting
mdl_puma560;
q = [0, -pi/4, 0, 0, pi/4, 0];
rpy_pbvs_plot = [];
cam_pbvs_pos_plot = [];
q_pbvs_plot = [];
t_pbvs_plot = [];

%get the end effector position and set the camera at that position
T = p560.fkine(q);
cam.T = T;

%this transform defines where the object starts relative to my initial robo
%configuration
%this moves the object -0.2 meters in the x and 1 meter in z away from my
%camera/end effector position
move_obj_position = [-0.2; 0; 1;];
T_points = T*[rotz(pi/2), move_obj_position;
              0, 0, 0, 1];

%this is the definition of the nominal vertices for our object in
%homogenous coordinates
P_nom = [-0.1   0.1 -0.1   0.1;
         0.1    0.1 -0.1  -0.1;
         0      0    0      0;
         1      1    1      1];

%this is transforming the nominal object model out to its actual location
P = T_points*P_nom;
P = P(1:3,:);

%get the pixel coordinates of the object in the camera now
p = cam.project(P);
cam.plot(P)

%from that we can estimate where the object is relative to the camera at
%least
T_est_cam = cam.estpose(P_nom, p);

%then we can define a desired position for the camera relative to the
%object, which in this case is just 0.5 meters back in the z-direction and
%aligned with the object
T_des = T*T_est_cam*[eye(3), [0; 0; -0.5];
                     0 0 0 1];

%plot everything for the initial conditions                 
figure()
p560.plot(q)
cam.plot_camera()
plot_sphere(P, 0.05, 'r')

%this is just a starting condition for the while loop
error = 1;

time = 0;
while error > 0.001
    %find how we can take small step towards our desired camera position
    T_cmd = trinterp(T, T_des, 0.1);
    time = time + 0.1; %assume it takes 0.1 seconds to get there
    
    %do inverse kinematics to find the new commanded joint angles. The
    %assumption is that we immediately are able to attain those angles.
    %Could also do this in terms of joint velocities if preferred.
    q = p560.ikine(T_cmd, q); 
    
    %find how the end effector and camera have moved based on our robot
    %kinematic  model
    T = p560.fkine(q);
    cam.T = T;

    %update all plots
    cam.plot(P)
    p560.plot(q)
    cam.plot_camera()
    plot_sphere(P, 0.05, 'r')

    %project the object into the camera image plane now that we've moved
    p = cam.project(P);
    
    %solve for the relative pose of the object with respect to the camera
    %agian
    T_est_cam = cam.estpose(P_nom, p);
    
    %and define a desired camera pose relative to that position for the
    %camera
    T_des = T*T_est_cam*[eye(3), [0; 0; -0.5];
        0 0 0 1];
    
    %calculate our error in terms of roll, pitch, yaw and then position too
    rpy_des = tr2rpy(T_des);
    rpy = tr2rpy(T);
    error = norm(T(1:3,4)-T_des(1:3,4))+norm(rpy_des-rpy);

    rpy_pbvs_plot = [rpy_pbvs_plot; rpy];
    cam_pbvs_pos_plot = [cam_pbvs_pos_plot; T(1:3,4)'];
    q_pbvs_plot = [q_pbvs_plot; q];
    t_pbvs_plot = [t_pbvs_plot; time];

end

