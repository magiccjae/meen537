function tau = computed_torque(robot, t, q, qd, q_goal, qd_goal)

M = robot.inertia(q);
G = (robot.gravload(q))';
C = robot.coriolis(q,qd)*qd';
Kp = diag(80*ones(robot.n,1));
Kd = diag(50*ones(robot.n,1));
tau = inv(M)*(Kp*(q_goal'-q') + Kd*(qd_goal' - qd')) + G + C;
tau = tau';

end